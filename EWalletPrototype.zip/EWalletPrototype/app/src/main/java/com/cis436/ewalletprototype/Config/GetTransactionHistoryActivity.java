package com.cis436.ewalletprototype.Config;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.cis436.ewalletprototype.R;

public class GetTransactionHistoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_transaction_history);

    }
}
