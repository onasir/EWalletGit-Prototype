package com.cis436.ewalletprototype.Config;

public class Config {
    public static final String PAYPAL_CLIENT_ID="Af6qRBx6zErU5U_mO4fGf5kHtelY6WckTwsKeYYiamtDwWJVEnkkn3oBN52OnfvsPCveJkjVf06tsOLG";
}
